package co.id.kedai.kedaiapp.fragment.beranda

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import co.id.kedai.kedaiapp.adapter.RvAdapterDataBlog
import co.id.kedai.kedaiapp.api.ApiClient
import co.id.kedai.kedaiapp.databinding.FragmentBlogBinding
import co.id.kedai.kedaiapp.model.DataResponse
import co.id.kedai.kedaiapp.model.DataResult
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class JaringanFragment : Fragment() {

    private var _binding: FragmentBlogBinding? = null
    private val binding get() = _binding!!
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var adapter: RvAdapterDataBlog
    val dataBlog: ArrayList<DataResult> = ArrayList()

    var isLoading = true
    var previousTotal = 0
    var pageNumber = 1

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        if (activity != null && isAdded) {

            // Inflate the layout for this fragment
            _binding = FragmentBlogBinding.inflate(inflater, container, false)
            return binding.root
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (activity != null && isAdded) {

            binding.shimmerBlog.stopShimmer()
            binding.shimmerBlog.isVisible = false
            layoutManager = LinearLayoutManager(activity?.applicationContext)
            binding.rvBlog.layoutManager = layoutManager
            binding.swipeRefresh.isRefreshing = true

            showDataNetworkBlog()

            binding.swipeRefresh.setOnRefreshListener {
                isLoading = true
                previousTotal = 0
                pageNumber = 1
                dataBlog.clear()
                showDataNetworkBlog()
            }

            binding.rvBlog.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    var visibleItemCount = layoutManager.childCount
                    var totalItemCount = layoutManager.itemCount
                    var pastVisibleItems = layoutManager.findFirstCompletelyVisibleItemPosition()
                    val view_threshold = 5

                    if (dy > 0) {

                        if (isLoading && totalItemCount > previousTotal) {
                            isLoading = false
                            previousTotal = totalItemCount
                            Log.e("dataKosong", "$totalItemCount")
                        }

                        if (!isLoading && totalItemCount - visibleItemCount <= pastVisibleItems + view_threshold
                        ) {
//                        Toast.makeText(activity, "$dy", Toast.LENGTH_SHORT).show()

                            pageNumber += 1
                            loadPage(pageNumber)
                            isLoading = true
                        }
                    }
                }
            })
        }
    }

    private fun loadPage(pageNumber: Int) {
        if (activity != null && isAdded) {

            ApiClient.instances.getDataAllBlog("network", pageNumber)
                .enqueue(object : Callback<DataResponse> {
                    override fun onResponse(
                        call: Call<DataResponse>,
                        response: Response<DataResponse>
                    ) {
                        if (response.isSuccessful) {
                            response.body()?.let {
                                adapter.addBlog(it.data)
                            }
                        } else dataBlog.clear()

                        binding.swipeRefresh.isRefreshing = false

                    }

                    override fun onFailure(call: Call<DataResponse>, t: Throwable) {
                        dataBlog.clear()
                        binding.swipeRefresh.isRefreshing = false
                    }

                })
        }
    }

    private fun showDataNetworkBlog() {
        if (activity != null && isAdded) {

            ApiClient.instances.getDataAllBlog("network", 1)
                .enqueue(object : Callback<DataResponse> {
                    override fun onResponse(
                        call: Call<DataResponse>,
                        response: Response<DataResponse>
                    ) {
                        adapter = RvAdapterDataBlog(response.body()!!.data)

                        if (response.isSuccessful) {

                            Log.e("response", "isSuccesfull --> ${response.code()}")
                            Log.e("response", "isSuccesfull --> ${response.message()}")

                            binding.layoutBlog.isVisible = true

                            binding.rvBlog.adapter = adapter
                            binding.swipeRefresh.isRefreshing = false

                        } else {
                            dataBlog.clear()
                            Log.e("response ", response.message())
                            binding.swipeRefresh.isRefreshing = false

                        }
                    }

                    override fun onFailure(call: Call<DataResponse>, t: Throwable) {

                        Log.e("response ", t.message.toString())
                        dataBlog.clear()
                        binding.swipeRefresh.isRefreshing = false

                    }

                })

        }
    }
    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}
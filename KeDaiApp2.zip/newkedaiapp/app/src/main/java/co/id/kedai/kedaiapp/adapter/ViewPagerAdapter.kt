package co.id.kedai.kedaiapp.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import co.id.kedai.kedaiapp.fragment.beranda.*

class ViewPagerAdapter(fragmentManager: FragmentManager, lifecycle: Lifecycle) :
    FragmentStateAdapter(fragmentManager, lifecycle) {

    override fun getItemCount(): Int = 6

    override fun createFragment(position: Int): Fragment {

        return when (position) {
            0 -> TerkiniFragment()
            1 -> ProgramFragment()
            2 -> JaringanFragment()
            3 -> MultimediaFragment()
            4 -> SysadminFragment()
            5 -> HardwareFragment()
            else -> Fragment()
        }
    }
}

//package co.id.kedai.kedaiapp.adapter;
//
//import androidx.annotation.NonNull;
//import androidx.fragment.app.Fragment;
//import androidx.fragment.app.FragmentManager;
//import androidx.lifecycle.Lifecycle;
//import androidx.viewpager2.adapter.FragmentStateAdapter;
//
//import co.id.kedai.kedaiapp.fragment.beranda.HardwareFragment;
//import co.id.kedai.kedaiapp.fragment.beranda.JaringanFragment;
//import co.id.kedai.kedaiapp.fragment.beranda.MultimediaFragment;
//import co.id.kedai.kedaiapp.fragment.beranda.ProgramFragment;
//import co.id.kedai.kedaiapp.fragment.beranda.SysadminFragment;
//import co.id.kedai.kedaiapp.fragment.beranda.TerkiniFragment;
//
//public class ViewPagerAdapter extends FragmentStateAdapter {
//
//    public ViewPagerAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
//        super(fragmentManager, lifecycle);
//    }
//
//    @NonNull
//    @Override
//    public Fragment createFragment(int position) {
//
//        switch (position) {
//            case 0 :
//            return new TerkiniFragment();
//            case 1 :
//            return new ProgramFragment();
//            case 2 :
//            return new JaringanFragment();
//            case 3 :
//            return new MultimediaFragment();
//            case 4 :
//            return new SysadminFragment();
//            case 5 :
//            return new HardwareFragment();
//        }
//        return null;
//    }
//
//    @Override
//    public int getItemCount() {
//        return 6;
//    }
//}


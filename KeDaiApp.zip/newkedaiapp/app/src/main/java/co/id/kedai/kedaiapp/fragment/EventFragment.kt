package co.id.kedai.kedaiapp.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import co.id.kedai.kedaiapp.R
import co.id.kedai.kedaiapp.adapter.RvAdapterDataEvent
import co.id.kedai.kedaiapp.api.ApiClient
import co.id.kedai.kedaiapp.model.DataResponse
import kotlinx.android.synthetic.main.fragment_ebook.swipe_refresh
import kotlinx.android.synthetic.main.fragment_event.*
import retrofit2.Call
import retrofit2.Response

class EventFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_event, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        shimmer_event.startShimmer()

        showDataEvent()

        swipe_refresh.setOnRefreshListener {
            showDataEvent()
        }
    }

    private fun showDataEvent() {
        val dataEvent: ArrayList<DataResponse.DataResult> = ArrayList()
        rv_event.setHasFixedSize(true)
        rv_event.layoutManager = LinearLayoutManager(context)

        ApiClient.instances.getDataEvent(1)
            .enqueue(object : retrofit2.Callback<DataResponse> {
                override fun onResponse(
                    call: Call<DataResponse>,
                    response: Response<DataResponse>
                ) {
                    val dataResponse = response.body()?.let { DataResponse(it.data) }
                    val adapter = dataResponse?.let { RvAdapterDataEvent(it) }

                    if (response.isSuccessful) {

                        Log.e("response", "isSuccesfull --> ${response.code()}")
                        Log.e("response", "isSuccesfull --> ${response.message()}")

                        rv_event.adapter = adapter
                        layout_event.isVisible = true
                        swipe_refresh.isRefreshing = false
                        shimmer_event.stopShimmer()
                        shimmer_event.isVisible = false

                    } else {

                        Log.e("response ", response.message())
                        swipe_refresh.isRefreshing = false
                        shimmer_event.stopShimmer()
                        shimmer_event.isVisible = false

                    }
                }

                override fun onFailure(call: Call<DataResponse>, t: Throwable) {

                    Log.e("response ", t.message.toString())

                    swipe_refresh.isRefreshing = false
                    shimmer_event.stopShimmer()
                    shimmer_event.isVisible = false

                }

            })

    }
}
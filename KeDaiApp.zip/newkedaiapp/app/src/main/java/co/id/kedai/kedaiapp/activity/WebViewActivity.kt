package co.id.kedai.kedaiapp.activity

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import co.id.kedai.kedaiapp.R
import co.id.kedai.kedaiapp.api.ApiClient
import kotlinx.android.synthetic.main.activity_web_view.*

class WebViewActivity : AppCompatActivity() {

    @SuppressLint("SetJavaScriptEnabled")
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web_view)
        supportActionBar?.hide()

        val sb: StringBuilder = StringBuilder()

        val id = intent.getStringExtra("id")
        val category = intent.getStringExtra("category")

        sb.append(ApiClient.URL_WEBVIEW)
        sb.append(category)
        sb.append(id)

        fab_back.setOnClickListener { onBackPressed() }

        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(webView: WebView, i: Int) {
                if (i == 100) {
                    progress_bar.isVisible = false
//                    Toast.makeText(this@WebViewActivity, sb.toString(), Toast.LENGTH_SHORT).show()
                }
            }
        }

        webView.loadUrl(sb.toString())
    }

}


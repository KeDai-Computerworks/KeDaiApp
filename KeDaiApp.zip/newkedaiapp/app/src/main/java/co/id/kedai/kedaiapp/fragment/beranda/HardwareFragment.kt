package co.id.kedai.kedaiapp.fragment.beranda

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import co.id.kedai.kedaiapp.R
import co.id.kedai.kedaiapp.adapter.RvAdapterDataBlog
import co.id.kedai.kedaiapp.api.ApiClient
import co.id.kedai.kedaiapp.model.DataResponse
import kotlinx.android.synthetic.main.fragment_blog.*
import retrofit2.Call
import retrofit2.Response

class HardwareFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_blog, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        swipe_refresh.isRefreshing = true

        showDataHardwareBlog()

        swipe_refresh.setOnRefreshListener {
            showDataHardwareBlog()
        }
    }
    private fun showDataHardwareBlog() {

        val dataBlog: ArrayList<DataResponse.DataResult> = ArrayList()
        rv_blog.setHasFixedSize(true)
        rv_blog.layoutManager = LinearLayoutManager(context)

        ApiClient.instances.getDataAllBlog("hardware", 1)
            .enqueue(object : retrofit2.Callback<DataResponse> {
                override fun onResponse(
                    call: Call<DataResponse>,
                    response: Response<DataResponse>
                ) {

                    val dataResponse = response.body()?.let { DataResponse(it.data) }
                    val adapter = dataResponse?.let { RvAdapterDataBlog(it) }
                    if (response.isSuccessful) {

                        Log.e("response", "isSuccesfull --> ${response.code()}")
                        Log.e("response", "isSuccesfull --> ${response.message()}")

                        rv_blog.adapter = adapter
                        swipe_refresh.isRefreshing = false

                    } else {
                        dataBlog.clear()
                        Log.e("response ", response.message())
                        swipe_refresh.isRefreshing = false

                    }
                }

                override fun onFailure(call: Call<DataResponse>, t: Throwable) {

                    Log.e("response ", t.message.toString())
                    dataBlog.clear()
                    swipe_refresh.isRefreshing = false

                }

            })

    }
}
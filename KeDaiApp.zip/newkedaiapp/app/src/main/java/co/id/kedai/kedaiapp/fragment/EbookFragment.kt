package co.id.kedai.kedaiapp.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import co.id.kedai.kedaiapp.adapter.RvAdapterDataEbook
import co.id.kedai.kedaiapp.api.ApiClient
import co.id.kedai.kedaiapp.databinding.FragmentEbookBinding
import co.id.kedai.kedaiapp.model.DataResponse
import retrofit2.Call
import retrofit2.Response

class EbookFragment : Fragment() {

    private var _binding: FragmentEbookBinding? = null
    private val binding get() = _binding!!
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var adapter: RvAdapterDataEbook

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentEbookBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var isLoading: Boolean = true
        var previousTotal = 0
        var pageNumber = 1

        layoutManager = LinearLayoutManager(activity?.applicationContext)
        binding.shimmerEbook.startShimmer()

        showDataResponse()
        binding.swipeRefresh.setOnRefreshListener {
            showDataResponse()
        }


        binding.rvEbook.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

                val visibleItemCount = layoutManager.childCount
                val totalItemCount = layoutManager.itemCount
                val pastVisibleItems = layoutManager.findFirstCompletelyVisibleItemPosition()
                val view_threshold = 5

                if (dy > 0) {
                    if (isLoading && totalItemCount > previousTotal) {
                        isLoading = false
                        previousTotal = totalItemCount
                    }

                    if (!isLoading && totalItemCount - visibleItemCount <= pastVisibleItems + view_threshold
                    ) {
                        pageNumber += 1
                        loadPage(pageNumber)
                        isLoading = true
                    }
                }
            }
        })
    }

    private fun loadPage(pageNumber: Int) {
        val dataEbook: ArrayList<DataResponse.DataResult> = ArrayList()

        ApiClient.instances.getDataEbook(pageNumber)
            .enqueue(object : retrofit2.Callback<DataResponse> {
                override fun onResponse(
                    call: Call<DataResponse>,
                    response: Response<DataResponse>
                ) {
                    val dataResponse = response.body()?.let { DataResponse(it.data) }
//                    val adapter = dataResponse?.let { RvAdapterDataEbook(it) }
                    if (response.isSuccessful) {

                        adapter.addEbook(response.body()!!.data)
                        Log.e("data","$response.body()!!.data")
                        binding.swipeRefresh.isRefreshing = false
                    } else dataEbook.clear()
                    binding.swipeRefresh.isRefreshing = false
                    Log.e("response ", response.code().toString())
                }

                override fun onFailure(call: Call<DataResponse>, t: Throwable) {
                    Log.e("response ", t.message.toString())
                    dataEbook.clear()
                    binding.swipeRefresh.isRefreshing = false

                }

            })
    }

    private fun showDataResponse() {

        val dataEbook: ArrayList<DataResponse.DataResult> = ArrayList()
        binding.rvEbook.setHasFixedSize(true)
        binding.rvEbook.layoutManager = LinearLayoutManager(context)

        ApiClient.instances.getDataEbook(1).enqueue(object : retrofit2.Callback<DataResponse> {
            override fun onResponse(call: Call<DataResponse>, response: Response<DataResponse>) {
                val dataResponse = response.body()?.let { DataResponse(it.data) }
                val adapter = dataResponse?.let { RvAdapterDataEbook(it) }
                if (response.isSuccessful) {

                    Log.e("response", "isSuccesfull --> ${response.code()}")
                    Log.e("response", "isSuccesfull --> ${response.message()}")

                    binding.rvEbook.adapter = adapter
                    binding.layoutEbook.isVisible = true
                    binding.swipeRefresh.isRefreshing = false
                    binding.shimmerEbook.stopShimmer()
                    binding.shimmerEbook.isVisible = false

                } else {
                    dataEbook.clear()
                    Log.e("response ", response.message())
                    binding.swipeRefresh.isRefreshing = false
                    binding.shimmerEbook.stopShimmer()
                    binding.shimmerEbook.isVisible = false
                }

            }

            override fun onFailure(call: Call<DataResponse>, t: Throwable) {
                Log.e("response ", t.message.toString())
                dataEbook.clear()
                binding.swipeRefresh.isRefreshing = false
                binding.shimmerEbook.stopShimmer()
                binding.shimmerEbook.isVisible = false
            }
        })
    }


}

package co.id.kedai.kedaiapp.activity

import android.app.ProgressDialog
import android.os.Bundle
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isGone
import androidx.core.view.isVisible
import co.id.kedai.kedaiapp.R
import co.id.kedai.kedaiapp.api.ApiClient
import com.github.barteksc.pdfviewer.listener.OnLoadCompleteListener
import com.github.barteksc.pdfviewer.listener.OnPageErrorListener
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle
import com.krishna.fileloader.FileLoader
import com.krishna.fileloader.builder.FileLoaderBuilder
import com.krishna.fileloader.listener.FileRequestListener
import com.krishna.fileloader.pojo.FileResponse
import com.krishna.fileloader.request.FileLoadRequest
import kotlinx.android.synthetic.main.activity_pdf_reader.*
import kotlinx.android.synthetic.main.activity_pdf_reader.fab_back
import kotlinx.android.synthetic.main.activity_web_view.*
import java.io.File

class PdfReaderActivity : AppCompatActivity(), OnLoadCompleteListener, OnPageErrorListener {

    private val sb: StringBuilder = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pdf_reader)
        supportActionBar?.hide()

        val with: FileLoaderBuilder = FileLoader.with(this)
        val path = intent.getStringExtra("path")

        sb.append(ApiClient.URL)
        sb.append(path)

        fab_back.setOnClickListener { onBackPressed() }

        with.load(sb.toString(), false)
            .fromDirectory("KeDaiApp-FilesPDF", FileLoader.DIR_INTERNAL)
            .asFile(object : FileRequestListener<File> {
                override fun onLoad(request: FileLoadRequest?, response: FileResponse<File>?) {
                    try {
                        pdfView.fromFile(response?.body)
                            .defaultPage(1)
                            .enableAnnotationRendering(true)
                            .onLoad(this@PdfReaderActivity)
                            .scrollHandle(DefaultScrollHandle(this@PdfReaderActivity))
                            .spacing(10)
                            .onPageError(this@PdfReaderActivity)
                            .load()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                override fun onError(request: FileLoadRequest?, t: Throwable?) {

                    Toast.makeText(this@PdfReaderActivity, "${t!!.message}", Toast.LENGTH_SHORT)
                        .show()
                }

            })
    }

    override fun loadComplete(nbPages: Int) {
        progress_bar_pdf.isVisible = false
        Toast.makeText(this, "sukses", Toast.LENGTH_SHORT).show()

    }

    override fun onPageError(page: Int, t: Throwable?) {
        progress_bar_pdf.isVisible = false
        Toast.makeText(this, t?.message, Toast.LENGTH_SHORT).show()
    }

}



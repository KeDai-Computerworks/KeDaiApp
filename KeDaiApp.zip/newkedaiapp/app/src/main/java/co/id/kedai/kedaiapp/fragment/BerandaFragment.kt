package co.id.kedai.kedaiapp.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import co.id.kedai.kedaiapp.R
import co.id.kedai.kedaiapp.adapter.ViewPagerAdapter
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.android.synthetic.main.fragment_beranda.*

class BerandaFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_beranda, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        val adapter = ViewPagerAdapter(activity!!.supportFragmentManager, activity!!.lifecycle)

        view_pager.adapter = adapter

//        tab_layout.setSelectedTabIndicatorColor(Color.parseColor("#ACE7F8"))
        TabLayoutMediator(tab_layout,view_pager) {tab,position->
            when(position){
                0 -> tab.text = "TERKINI"
                1 -> tab.text = "PROGRAM"
                2 -> tab.text = "JARINGAN"
                3 -> tab.text = "MULTIMEDIA"
                4 -> tab.text = "SYSADMIN"
                5 -> tab.text = "HARDWARE"
            }
        }.attach()

    }
}
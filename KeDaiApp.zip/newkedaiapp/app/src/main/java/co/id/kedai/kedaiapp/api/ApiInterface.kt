package co.id.kedai.kedaiapp.api

import co.id.kedai.kedaiapp.model.DataResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiInterface {

    @GET("/api/ebooks")
    fun getDataEbook(@Query("page") page: Int) :
            Call<DataResponse>

    @GET("/api/{category}/posts")
    fun getDataAllBlog(@Path("category") category: String,
                       @Query("page") page: Int) :
            Call<DataResponse>

    @GET("/api/events")
    fun getDataEvent(@Query("page") page: Int) :
            Call<DataResponse>
}
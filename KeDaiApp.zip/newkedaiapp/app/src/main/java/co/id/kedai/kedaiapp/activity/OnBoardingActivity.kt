package co.id.kedai.kedaiapp.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import androidx.core.view.get
import androidx.viewpager2.widget.ViewPager2
import co.id.kedai.kedaiapp.MainActivity
import co.id.kedai.kedaiapp.R
import co.id.kedai.kedaiapp.adapter.AdapterOnBoarding
import co.id.kedai.kedaiapp.model.DataOnBoarding
import kotlinx.android.synthetic.main.activity_on_boarding.*

class OnBoardingActivity : AppCompatActivity() {

    private val adapterOnBoarding = AdapterOnBoarding(
        listOf(
            DataOnBoarding(
                "Blog",
                "Selalu update dengan berbagai macam berita " +
                        "dan materi terbaru seputar dunia teknologi",
                R.drawable.onboarding_berita
            ),
            DataOnBoarding(
                "E-Book",
                "Dapatkan berbagai macam buku elektronik yang " +
                        "akan menambah wawasanmu seputar dunia teknologi",
                R.drawable.onboarding_ebook
            ),
            DataOnBoarding(
                "Acara",
                "Temukan berbagai macam acara atau kegiatan " +
                        "menarik dari KeDai Computerworks",
                R.drawable.onboarding_acara
            )
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_on_boarding)
        supportActionBar?.hide()

        val intent = Intent(applicationContext, MainActivity::class.java)

        if (restoreData()) {
            startActivity(intent)
            finish()
        }

        sliderView.adapter = adapterOnBoarding

        setupIndicator()
        setCurrentIndicator(0)

        sliderView.registerOnPageChangeCallback(object :
            ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                setCurrentIndicator(position)
            }
        })

        btn_next.setOnClickListener {
            if (sliderView.currentItem + 1 <
                adapterOnBoarding.itemCount
            ) {
                sliderView.currentItem += 1
            } else {
                startActivity(intent)
                dataSave()
                finish()
            }
        }

        tv_skip.setOnClickListener {
            startActivity(intent)
            dataSave()
            finish()
        }
    }

    private fun setupIndicator() {
        val indicator = arrayOfNulls<ImageView>(adapterOnBoarding.itemCount)
        val layoutParams: LinearLayout.LayoutParams =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        layoutParams.setMargins(10, 0, 10, 0)

        for (i in indicator.indices) {
            indicator[i] = ImageView(applicationContext)
            indicator[i].apply {
                this?.setImageDrawable(
                    ContextCompat.getDrawable(
                        applicationContext, R.drawable.indicator_off
                    )
                )
                this?.layoutParams = layoutParams
            }
            indicator_container.addView(indicator[i])
        }
    }

    private fun setCurrentIndicator(index: Int) {
        val childCount = indicator_container.childCount
        for (i in 0 until childCount) {
            val imageView = indicator_container[i] as ImageView
            if (i == index) {
                imageView.setImageDrawable(
                    ContextCompat.getDrawable(
                        applicationContext, R.drawable.indicator_on
                    )
                )
            } else {
                imageView.setImageDrawable(
                    ContextCompat.getDrawable(
                        applicationContext, R.drawable.indicator_off
                    )
                )
            }
        }
    }

    private fun dataSave() {
        val sharedPreferences = applicationContext.getSharedPreferences(
            "onboarding", Context.MODE_PRIVATE
        )
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putBoolean("state_onboarding", true)
        editor.apply()
    }

    private fun restoreData(): Boolean {
        val sharedPreferences = applicationContext.getSharedPreferences(
            "onboarding", Context.MODE_PRIVATE
        )
        return sharedPreferences.getBoolean("state_onboarding", false)
    }
}